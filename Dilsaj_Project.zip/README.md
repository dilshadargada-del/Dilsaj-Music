
Dilsaj Music - Demo Starter

This is a demo starter project for Dilsaj Music (offline demo + earning wallet + AI mood suggestions).

What's included:
- Flutter project skeleton (lib/, assets/)
- Demo songs referenced from bensound.com (example placeholder)
- Wallet demo screen (coins)
- Simple AI mood suggester (offline demo logic)
- Assets: dilsaj_logo.png placeholder

How to use:
1. Download this ZIP, extract the folder.
2. Place into a Flutter project or open in Android Studio/VS Code.
3. Run `flutter pub get` then `flutter run`.
