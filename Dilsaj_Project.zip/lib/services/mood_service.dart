
class MoodSuggester {
  static List<String> suggestions(String mood) {
    switch(mood.toLowerCase()) {
      case 'happy': return ['Morning Breeze','Sunny'];
      case 'sad': return ['Better Days'];
      default: return ['Morning Breeze','Better Days','Sunny'];
    }
  }
}
