
import 'package:flutter/material.dart';
import 'screens/splash.dart';

void main() {
  runApp(const DilsajApp());
}

class DilsajApp extends StatelessWidget {
  const DilsajApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dilsaj Music',
      theme: ThemeData.dark().copyWith(
        primaryColor: Color(0xFFFFD700),
        scaffoldBackgroundColor: Colors.black,
      ),
      home: const SplashScreen(),
    );
  }
}
