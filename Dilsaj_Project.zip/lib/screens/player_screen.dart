
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';

class PlayerScreen extends StatefulWidget {
  final String url;
  final String title;
  const PlayerScreen({Key? key, required this.url, required this.title}) : super(key: key);

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  final AudioPlayer _player = AudioPlayer();
  @override
  void initState() {
    super.initState();
    _player.setUrl(widget.url).then((_) => _player.play());
  }
  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }
  String _format(Duration d) => "${d.inMinutes.remainder(60).toString().padLeft(2,'0')}:${d.inSeconds.remainder(60).toString().padLeft(2,'0')}";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: Column(children: [
        const SizedBox(height:20),
        Image.asset('assets/dilsaj_logo.png', width:200,height:200),
        const SizedBox(height:12),
        StreamBuilder<Duration?>(stream: _player.durationStream, builder: (c,s){ final total=s.data??Duration.zero; return StreamBuilder<Duration>(stream: _player.positionStream, builder:(c,pos){ final p=pos.data??Duration.zero; return Column(children:[ Slider(min:0,max: total.inMilliseconds.toDouble(), value: p.inMilliseconds.clamp(0,total.inMilliseconds).toDouble(), onChanged:(v){ _player.seek(Duration(milliseconds: v.toInt())); }), Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children:[ Text(_format(p)), Text(_format(total)) ]) ]); }); }),
        Row(mainAxisAlignment: MainAxisAlignment.center, children:[ IconButton(icon: const Icon(Icons.pause), onPressed: (){ _player.pause(); }), IconButton(icon: const Icon(Icons.play_arrow), onPressed: (){ _player.play(); }), IconButton(icon: const Icon(Icons.stop), onPressed: (){ _player.stop(); }) ])
      ],),
    );
  }
}
