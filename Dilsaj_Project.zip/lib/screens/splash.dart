
import 'package:flutter/material.dart';
import 'home.dart';
import 'dart:async';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds:2), () {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomeScreen()));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Image.asset('assets/dilsaj_logo.png', width:160),
          const SizedBox(height:12),
          Text('Dilsaj Music', style: TextStyle(fontSize:26, fontWeight: FontWeight.bold, color: Color(0xFFFFD700))),
          const SizedBox(height:6),
          Text('Feel the Beat', style: TextStyle(color: Colors.white70)),
        ]),
      ),
    );
  }
}
