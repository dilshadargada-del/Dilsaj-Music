
import 'package:flutter/material.dart';
import 'player_screen.dart';
import 'wallet.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  final demoSongs = const [
    {'title':'Morning Breeze','artist':'Dilsaj','url':'https://www.bensound.com/bensound-music/bensound-acousticbreeze.mp3'},
    {'title':'Better Days','artist':'Dilsaj','url':'https://www.bensound.com/bensound-music/bensound-betterdays.mp3'},
    {'title':'Sunny','artist':'Dilsaj','url':'https://www.bensound.com/bensound-music/bensound-sunny.mp3'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Dilsaj Music')),
      body: ListView.builder(
        itemCount: demoSongs.length,
        itemBuilder: (context, index) {
          final s = demoSongs[index];
          return ListTile(
            leading: Image.asset('assets/dilsaj_logo.png', width:50, height:50),
            title: Text(s['title']!),
            subtitle: Text(s['artist']!),
            trailing: IconButton(icon: const Icon(Icons.play_arrow), onPressed: (){
              Navigator.push(context, MaterialPageRoute(builder: (_) => PlayerScreen(url: s['url']!, title: s['title']!)));
            }),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.account_balance_wallet),
        onPressed: () { Navigator.push(context, MaterialPageRoute(builder: (_) => const WalletScreen())); },
      ),
    );
  }
}
