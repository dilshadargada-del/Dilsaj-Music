
import 'package:flutter/material.dart';

class WalletScreen extends StatefulWidget {
  const WalletScreen({Key? key}) : super(key: key);
  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  int coins = 120;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Wallet')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(children: [
          Card(child: ListTile(title: const Text('Coins Balance'), trailing: Text('\$coins')),),
          const SizedBox(height:12),
          ElevatedButton(onPressed: () { setState(()=> coins += 10); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Coins rewarded (demo)'))); }, child: const Text('Watch Reward Ad (Demo)')),
        ]),
      ),
    );
  }
}
