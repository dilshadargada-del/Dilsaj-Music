
const functions = require('firebase-functions');
const admin = require('firebase-admin');
admin.initializeApp();
const db = admin.firestore();

exports.logPlay = functions.https.onCall(async (data, context) => {
  const { songId, playedSeconds } = data;
  if (!context.auth) throw new functions.https.HttpsError('unauthenticated', 'Login required');
  const userId = context.auth.uid;
  const playRef = db.collection('songs').doc(songId).collection('plays').doc();
  await playRef.set({ userId, playedSeconds, ts: admin.firestore.FieldValue.serverTimestamp() });
  await db.collection('songs').doc(songId).update({ playsCount: admin.firestore.FieldValue.increment(1) });
  return { success: true };
});
